package androidx.activity;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public abstract class OnBackPressedCallback {
  private CopyOnWriteArrayList<Cancellable> mCancellables = new CopyOnWriteArrayList<Cancellable>();
  
  private boolean mEnabled;
  
  public OnBackPressedCallback(boolean paramBoolean) {
    this.mEnabled = paramBoolean;
  }
  
  void addCancellable(@NonNull Cancellable paramCancellable) {
    this.mCancellables.add(paramCancellable);
  }
  
  @MainThread
  public abstract void handleOnBackPressed();
  
  @MainThread
  public final boolean isEnabled() {
    return this.mEnabled;
  }
  
  @MainThread
  public final void remove() {
    Iterator<Cancellable> iterator = this.mCancellables.iterator();
    while (iterator.hasNext())
      ((Cancellable)iterator.next()).cancel(); 
  }
  
  void removeCancellable(@NonNull Cancellable paramCancellable) {
    this.mCancellables.remove(paramCancellable);
  }
  
  @MainThread
  public final void setEnabled(boolean paramBoolean) {
    this.mEnabled = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Arm Wrestling1-dex2jar.jar!\androidx\activity\OnBackPressedCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */