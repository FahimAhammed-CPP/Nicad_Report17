package androidx.appcompat.graphics.drawable;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import androidx.annotation.ColorInt;
import androidx.annotation.FloatRange;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class DrawerArrowDrawable extends Drawable {
  public static final int ARROW_DIRECTION_END = 3;
  
  public static final int ARROW_DIRECTION_LEFT = 0;
  
  public static final int ARROW_DIRECTION_RIGHT = 1;
  
  public static final int ARROW_DIRECTION_START = 2;
  
  private static final float ARROW_HEAD_ANGLE = (float)Math.toRadians(45.0D);
  
  private float mArrowHeadLength;
  
  private float mArrowShaftLength;
  
  private float mBarGap;
  
  private float mBarLength;
  
  private int mDirection = 2;
  
  private float mMaxCutForBarSize;
  
  private final Paint mPaint = new Paint();
  
  private final Path mPath = new Path();
  
  private float mProgress;
  
  private final int mSize;
  
  private boolean mSpin;
  
  private boolean mVerticalMirror = false;
  
  public DrawerArrowDrawable(Context paramContext) {
    this.mPaint.setStyle(Paint.Style.STROKE);
    this.mPaint.setStrokeJoin(Paint.Join.MITER);
    this.mPaint.setStrokeCap(Paint.Cap.BUTT);
    this.mPaint.setAntiAlias(true);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(null, R.styleable.DrawerArrowToggle, R.attr.drawerArrowStyle, R.style.Base_Widget_AppCompat_DrawerArrowToggle);
    setColor(typedArray.getColor(R.styleable.DrawerArrowToggle_color, 0));
    setBarThickness(typedArray.getDimension(R.styleable.DrawerArrowToggle_thickness, 0.0F));
    setSpinEnabled(typedArray.getBoolean(R.styleable.DrawerArrowToggle_spinBars, true));
    setGapSize(Math.round(typedArray.getDimension(R.styleable.DrawerArrowToggle_gapBetweenBars, 0.0F)));
    this.mSize = typedArray.getDimensionPixelSize(R.styleable.DrawerArrowToggle_drawableSize, 0);
    this.mBarLength = Math.round(typedArray.getDimension(R.styleable.DrawerArrowToggle_barLength, 0.0F));
    this.mArrowHeadLength = Math.round(typedArray.getDimension(R.styleable.DrawerArrowToggle_arrowHeadLength, 0.0F));
    this.mArrowShaftLength = typedArray.getDimension(R.styleable.DrawerArrowToggle_arrowShaftLength, 0.0F);
    typedArray.recycle();
  }
  
  private static float lerp(float paramFloat1, float paramFloat2, float paramFloat3) {
    return paramFloat1 + (paramFloat2 - paramFloat1) * paramFloat3;
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getBounds : ()Landroid/graphics/Rect;
    //   4: astore #18
    //   6: aload_0
    //   7: getfield mDirection : I
    //   10: istore #17
    //   12: iconst_0
    //   13: istore #16
    //   15: iload #16
    //   17: istore #15
    //   19: iload #17
    //   21: ifeq -> 65
    //   24: iload #17
    //   26: iconst_1
    //   27: if_icmpeq -> 62
    //   30: iload #17
    //   32: iconst_3
    //   33: if_icmpeq -> 51
    //   36: iload #16
    //   38: istore #15
    //   40: aload_0
    //   41: invokestatic getLayoutDirection : (Landroid/graphics/drawable/Drawable;)I
    //   44: iconst_1
    //   45: if_icmpne -> 65
    //   48: goto -> 62
    //   51: iload #16
    //   53: istore #15
    //   55: aload_0
    //   56: invokestatic getLayoutDirection : (Landroid/graphics/drawable/Drawable;)I
    //   59: ifne -> 65
    //   62: iconst_1
    //   63: istore #15
    //   65: aload_0
    //   66: getfield mArrowHeadLength : F
    //   69: fstore #8
    //   71: fload #8
    //   73: fload #8
    //   75: fmul
    //   76: fconst_2
    //   77: fmul
    //   78: f2d
    //   79: invokestatic sqrt : (D)D
    //   82: d2f
    //   83: fstore #8
    //   85: aload_0
    //   86: getfield mBarLength : F
    //   89: fload #8
    //   91: aload_0
    //   92: getfield mProgress : F
    //   95: invokestatic lerp : (FFF)F
    //   98: fstore #12
    //   100: aload_0
    //   101: getfield mBarLength : F
    //   104: aload_0
    //   105: getfield mArrowShaftLength : F
    //   108: aload_0
    //   109: getfield mProgress : F
    //   112: invokestatic lerp : (FFF)F
    //   115: fstore #10
    //   117: fconst_0
    //   118: aload_0
    //   119: getfield mMaxCutForBarSize : F
    //   122: aload_0
    //   123: getfield mProgress : F
    //   126: invokestatic lerp : (FFF)F
    //   129: invokestatic round : (F)I
    //   132: i2f
    //   133: fstore #11
    //   135: fconst_0
    //   136: getstatic androidx/appcompat/graphics/drawable/DrawerArrowDrawable.ARROW_HEAD_ANGLE : F
    //   139: aload_0
    //   140: getfield mProgress : F
    //   143: invokestatic lerp : (FFF)F
    //   146: fstore #13
    //   148: iload #15
    //   150: ifeq -> 159
    //   153: fconst_0
    //   154: fstore #8
    //   156: goto -> 163
    //   159: ldc -180.0
    //   161: fstore #8
    //   163: iload #15
    //   165: ifeq -> 175
    //   168: ldc 180.0
    //   170: fstore #9
    //   172: goto -> 178
    //   175: fconst_0
    //   176: fstore #9
    //   178: fload #8
    //   180: fload #9
    //   182: aload_0
    //   183: getfield mProgress : F
    //   186: invokestatic lerp : (FFF)F
    //   189: fstore #8
    //   191: fload #12
    //   193: f2d
    //   194: dstore_2
    //   195: fload #13
    //   197: f2d
    //   198: dstore #4
    //   200: dload #4
    //   202: invokestatic cos : (D)D
    //   205: dstore #6
    //   207: dload_2
    //   208: invokestatic isNaN : (D)Z
    //   211: pop
    //   212: dload #6
    //   214: dload_2
    //   215: dmul
    //   216: invokestatic round : (D)J
    //   219: l2f
    //   220: fstore #9
    //   222: dload #4
    //   224: invokestatic sin : (D)D
    //   227: dstore #4
    //   229: dload_2
    //   230: invokestatic isNaN : (D)Z
    //   233: pop
    //   234: dload_2
    //   235: dload #4
    //   237: dmul
    //   238: invokestatic round : (D)J
    //   241: l2f
    //   242: fstore #12
    //   244: aload_0
    //   245: getfield mPath : Landroid/graphics/Path;
    //   248: invokevirtual rewind : ()V
    //   251: aload_0
    //   252: getfield mBarGap : F
    //   255: aload_0
    //   256: getfield mPaint : Landroid/graphics/Paint;
    //   259: invokevirtual getStrokeWidth : ()F
    //   262: fadd
    //   263: aload_0
    //   264: getfield mMaxCutForBarSize : F
    //   267: fneg
    //   268: aload_0
    //   269: getfield mProgress : F
    //   272: invokestatic lerp : (FFF)F
    //   275: fstore #13
    //   277: fload #10
    //   279: fneg
    //   280: fconst_2
    //   281: fdiv
    //   282: fstore #14
    //   284: aload_0
    //   285: getfield mPath : Landroid/graphics/Path;
    //   288: fload #14
    //   290: fload #11
    //   292: fadd
    //   293: fconst_0
    //   294: invokevirtual moveTo : (FF)V
    //   297: aload_0
    //   298: getfield mPath : Landroid/graphics/Path;
    //   301: fload #10
    //   303: fload #11
    //   305: fconst_2
    //   306: fmul
    //   307: fsub
    //   308: fconst_0
    //   309: invokevirtual rLineTo : (FF)V
    //   312: aload_0
    //   313: getfield mPath : Landroid/graphics/Path;
    //   316: fload #14
    //   318: fload #13
    //   320: invokevirtual moveTo : (FF)V
    //   323: aload_0
    //   324: getfield mPath : Landroid/graphics/Path;
    //   327: fload #9
    //   329: fload #12
    //   331: invokevirtual rLineTo : (FF)V
    //   334: aload_0
    //   335: getfield mPath : Landroid/graphics/Path;
    //   338: fload #14
    //   340: fload #13
    //   342: fneg
    //   343: invokevirtual moveTo : (FF)V
    //   346: aload_0
    //   347: getfield mPath : Landroid/graphics/Path;
    //   350: fload #9
    //   352: fload #12
    //   354: fneg
    //   355: invokevirtual rLineTo : (FF)V
    //   358: aload_0
    //   359: getfield mPath : Landroid/graphics/Path;
    //   362: invokevirtual close : ()V
    //   365: aload_1
    //   366: invokevirtual save : ()I
    //   369: pop
    //   370: aload_0
    //   371: getfield mPaint : Landroid/graphics/Paint;
    //   374: invokevirtual getStrokeWidth : ()F
    //   377: fstore #9
    //   379: aload #18
    //   381: invokevirtual height : ()I
    //   384: i2f
    //   385: fstore #11
    //   387: aload_0
    //   388: getfield mBarGap : F
    //   391: fstore #10
    //   393: fload #11
    //   395: ldc_w 3.0
    //   398: fload #9
    //   400: fmul
    //   401: fsub
    //   402: fconst_2
    //   403: fload #10
    //   405: fmul
    //   406: fsub
    //   407: f2i
    //   408: iconst_4
    //   409: idiv
    //   410: iconst_2
    //   411: imul
    //   412: i2f
    //   413: fstore #11
    //   415: aload_1
    //   416: aload #18
    //   418: invokevirtual centerX : ()I
    //   421: i2f
    //   422: fload #11
    //   424: fload #9
    //   426: ldc_w 1.5
    //   429: fmul
    //   430: fload #10
    //   432: fadd
    //   433: fadd
    //   434: invokevirtual translate : (FF)V
    //   437: aload_0
    //   438: getfield mSpin : Z
    //   441: ifeq -> 476
    //   444: aload_0
    //   445: getfield mVerticalMirror : Z
    //   448: iload #15
    //   450: ixor
    //   451: ifeq -> 460
    //   454: iconst_m1
    //   455: istore #15
    //   457: goto -> 463
    //   460: iconst_1
    //   461: istore #15
    //   463: aload_1
    //   464: fload #8
    //   466: iload #15
    //   468: i2f
    //   469: fmul
    //   470: invokevirtual rotate : (F)V
    //   473: goto -> 487
    //   476: iload #15
    //   478: ifeq -> 487
    //   481: aload_1
    //   482: ldc 180.0
    //   484: invokevirtual rotate : (F)V
    //   487: aload_1
    //   488: aload_0
    //   489: getfield mPath : Landroid/graphics/Path;
    //   492: aload_0
    //   493: getfield mPaint : Landroid/graphics/Paint;
    //   496: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   499: aload_1
    //   500: invokevirtual restore : ()V
    //   503: return
  }
  
  public float getArrowHeadLength() {
    return this.mArrowHeadLength;
  }
  
  public float getArrowShaftLength() {
    return this.mArrowShaftLength;
  }
  
  public float getBarLength() {
    return this.mBarLength;
  }
  
  public float getBarThickness() {
    return this.mPaint.getStrokeWidth();
  }
  
  @ColorInt
  public int getColor() {
    return this.mPaint.getColor();
  }
  
  public int getDirection() {
    return this.mDirection;
  }
  
  public float getGapSize() {
    return this.mBarGap;
  }
  
  public int getIntrinsicHeight() {
    return this.mSize;
  }
  
  public int getIntrinsicWidth() {
    return this.mSize;
  }
  
  public int getOpacity() {
    return -3;
  }
  
  public final Paint getPaint() {
    return this.mPaint;
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getProgress() {
    return this.mProgress;
  }
  
  public boolean isSpinEnabled() {
    return this.mSpin;
  }
  
  public void setAlpha(int paramInt) {
    if (paramInt != this.mPaint.getAlpha()) {
      this.mPaint.setAlpha(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setArrowHeadLength(float paramFloat) {
    if (this.mArrowHeadLength != paramFloat) {
      this.mArrowHeadLength = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setArrowShaftLength(float paramFloat) {
    if (this.mArrowShaftLength != paramFloat) {
      this.mArrowShaftLength = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setBarLength(float paramFloat) {
    if (this.mBarLength != paramFloat) {
      this.mBarLength = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setBarThickness(float paramFloat) {
    if (this.mPaint.getStrokeWidth() != paramFloat) {
      this.mPaint.setStrokeWidth(paramFloat);
      double d1 = (paramFloat / 2.0F);
      double d2 = Math.cos(ARROW_HEAD_ANGLE);
      Double.isNaN(d1);
      this.mMaxCutForBarSize = (float)(d1 * d2);
      invalidateSelf();
    } 
  }
  
  public void setColor(@ColorInt int paramInt) {
    if (paramInt != this.mPaint.getColor()) {
      this.mPaint.setColor(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.mPaint.setColorFilter(paramColorFilter);
    invalidateSelf();
  }
  
  public void setDirection(int paramInt) {
    if (paramInt != this.mDirection) {
      this.mDirection = paramInt;
      invalidateSelf();
    } 
  }
  
  public void setGapSize(float paramFloat) {
    if (paramFloat != this.mBarGap) {
      this.mBarGap = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setProgress(@FloatRange(from = 0.0D, to = 1.0D) float paramFloat) {
    if (this.mProgress != paramFloat) {
      this.mProgress = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setSpinEnabled(boolean paramBoolean) {
    if (this.mSpin != paramBoolean) {
      this.mSpin = paramBoolean;
      invalidateSelf();
    } 
  }
  
  public void setVerticalMirror(boolean paramBoolean) {
    if (this.mVerticalMirror != paramBoolean) {
      this.mVerticalMirror = paramBoolean;
      invalidateSelf();
    } 
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface ArrowDirection {}
}


/* Location:              C:\soft\dex2jar-2.0\Arm Wrestling1-dex2jar.jar!\androidx\appcompat\graphics\drawable\DrawerArrowDrawable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */