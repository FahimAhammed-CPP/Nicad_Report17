package androidx.core.text;

public interface TextDirectionHeuristicCompat {
  boolean isRtl(CharSequence paramCharSequence, int paramInt1, int paramInt2);
  
  boolean isRtl(char[] paramArrayOfchar, int paramInt1, int paramInt2);
}


/* Location:              C:\soft\dex2jar-2.0\Arm Wrestling1-dex2jar.jar!\androidx\core\text\TextDirectionHeuristicCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */